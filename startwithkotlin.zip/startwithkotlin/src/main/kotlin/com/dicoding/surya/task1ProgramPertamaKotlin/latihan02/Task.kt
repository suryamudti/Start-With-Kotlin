package com.dicoding.surya.task1ProgramPertamaKotlin.latihan02

/**
 * Created by suryamudti on 06/09/2019.
 */

fun main() {
    println(
        """"Kotlin,
            |is Awesome!
        """.trimMargin()
    )
}